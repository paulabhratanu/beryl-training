require 'test_helper'

class LabTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
